import { Component, OnInit } from '@angular/core';
import { ProductfeedserviceService} from '../productfeedservice.service';
import { Feedback} from '../feedback';
@Component({
  selector: 'app-productfeedback',
  templateUrl: './productfeedback.component.html',
  styleUrls: ['./productfeedback.component.css']
})
export class ProductfeedbackComponent implements OnInit {
  feedback: Feedback= new Feedback();
  result:any;
  constructor( private service :ProductfeedserviceService) { }

  ngOnInit() {
  }
  newUser(): void {
    this.feedback= new Feedback();
  }
  addProductFeedback(feedback): void {
    this.service.addProductfeedback(this.feedback)
        .subscribe( data => { this.result = data;
         console.log(this.result)
});
  };  
onSubmit() {
  this.addProductFeedback(this.feedback);
}
  }