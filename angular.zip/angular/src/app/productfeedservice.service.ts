import { Injectable } from '@angular/core';
import {HttpClient,HttpHeaders} from '@angular/common/http';
import {Observable} from '../../node_modules/rxjs';
@Injectable({
  providedIn: 'root'
})
export class ProductfeedserviceService {
private baseUrl='http://localhost:3456';

  constructor(private http:HttpClient) { }
 
  public addProductfeedback(feedback):Observable<any>{
   return this.http.post(`${this.baseUrl}`+`/productfeedback/1`,feedback);
   
  
}   
} 
