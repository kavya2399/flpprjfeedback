import { TestBed } from '@angular/core/testing';

import { ProductfeedserviceService } from './productfeedservice.service';

describe('ProductfeedserviceService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ProductfeedserviceService = TestBed.get(ProductfeedserviceService);
    expect(service).toBeTruthy();
  });
});
