export class Feedback {
    headline:string;
    review:string;
   
}
