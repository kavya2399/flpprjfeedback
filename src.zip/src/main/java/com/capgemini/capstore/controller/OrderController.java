package com.capgemini.capstore.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.capstore.bean.Carddetails;
import com.capgemini.capstore.bean.Customer_Orders;
import com.capgemini.capstore.bean.Product;
import com.capgemini.capstore.service.IOrderService;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class OrderController {

	@Autowired
	IOrderService service;
	@GetMapping("/total")
	public ResponseEntity<List<Customer_Orders>> getOrders() {
		List<Customer_Orders> list = new ArrayList<>();
		list = service.showOrders();
		return ResponseEntity.ok(list);
	}
	
	@GetMapping("/card")
	public ResponseEntity<List<Carddetails>> getDetails(){
		List<Carddetails> list = new ArrayList<>();
		list = service.showDetails();
		return ResponseEntity.ok(list);
		
	}
	
	@PostMapping("/total/card")
	public ResponseEntity<Carddetails> addCardDetails(@RequestBody Carddetails card){
		Carddetails result = service.insertCardDetails(card);
		return ResponseEntity.ok(result);
		
	}
	
	@GetMapping("/showprod")
	public ResponseEntity<List<Product>> getProductDetails(){
		List<Product> list2 = new ArrayList<>();
		list2 = service.showProductDetails();
		return ResponseEntity.ok(list2);
		
	}
	
	@PostMapping("/proddetail")
	public ResponseEntity<Product> addProductDetails(@RequestBody Product prod){
		Product res = service.addProducts(prod);
		return ResponseEntity.ok(res);
		
	}
	
	
	
	
	
}
