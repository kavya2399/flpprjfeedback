package com.capgemini.capstore.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capgemini.capstore.bean.Product;

public interface ProdRepo  extends JpaRepository<Product,Integer>{

}
