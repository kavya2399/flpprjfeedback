package com.capgemini.capstore.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capgemini.capstore.bean.Customer_Orders;

public interface OrderRepo extends JpaRepository<Customer_Orders,Integer>{

}
