package com.capgemini.capstore.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capgemini.capstore.bean.Carddetails;


public interface CardRepo extends JpaRepository<Carddetails,Integer>{

}
